package com.example.quizapp4;

import android.content.Intent;
import android.os.Bundle;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;

public class SplashActivity extends AppCompatActivity {

  private TextView appName;

  @Override
  protected void onCreate(Bundle savedInstanceState) {
    super.onCreate(savedInstanceState);
    setContentView(R.layout.activity_splash);

    appName = findViewById(R.id.app_name);

    Animation animation = AnimationUtils.loadAnimation(this, R.anim.animation);
    appName.setAnimation(animation);

    new Thread() {

      @Override
      public void run() {
        try {
          sleep(3000);
        } catch (InterruptedException e) {
          e.printStackTrace();
        }
        Intent intent = new Intent(SplashActivity.this, LoginActivity.class);
        startActivity(intent);
        SplashActivity.this.finish();
      }
    }.start();
  }
}
